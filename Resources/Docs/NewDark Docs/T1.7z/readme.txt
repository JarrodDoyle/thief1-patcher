Installation
------------

Before running the game in a Thief 1/G install you must add the config var "dark1" (NOT "game dark1") to the
"cam.cfg" (or "cam_ext.cfg"). Failure to do so will lead to strange things happening and ultimately a crash.


In order for option menus to look right, the provided "interface.crf" has to be added. Either by putting
it in a mod dir and adding it to the "mod_path" in "cam_mod.ini" or by placing it in a "patch" dir.

The option menus will not have the option for "Character Detail", like in the original game. Instead you'll
have make sure yourself that "cam.cfg" contains the line "character_detail 1", if you want the game to use the
higher detail character meshes.


Also included is a slightly patched "motiondb.bin", one for the original T1 release (in "TDP\") and one
for Thief Gold (in "TG\"). If you put "interface.crf" in a mod dir, then you can copy the correct "motiondb.bin"
in the same dir, otherwise you can replace "motiondb.bin" in the game's root dir.

The motiondb patch fixes a potential problem with idling AI not always turning correctly during scripted
events. For DromEd users: When using the "Face" pseudo-script action, in for example conversations, it will
not reliably work because the newer dark engine requires the idle motion to have a frame flag set. In the
"editor\" dir is an updated ".mi"-file with the flag set, that you can use if you need to rebuild the motiondb
yourself.



Misc
----

Note that at heart you're still running Thief 2. Not everything will be exactly like it was in Thief 1/G, and
some things may not work entirely without some fixing. Take it for what it is, a nice bonus that all in all works
good, but it's not intended to be 100% authentic and it's not flawless.

Some occasional mission may have problems with pathfinding, like an AI stopping to patrol, this is usually caused
by differences in T1 and T2 pathfinding code and/or the pathfinding db. It should be fixable by reportalizing and
rebuilding the pathfinding db in the latest DromEd.



Bunnyhop enthusiasts may get problems with the head lagging. To counter that, it requires increasing a max velocity
for limit for the head. This is done with following two config vars:

    springcap
    max_spring_vel 70

The max velocity may have to be adjusted empirically if 70 isn't enough. For reference, the default value is 25.
