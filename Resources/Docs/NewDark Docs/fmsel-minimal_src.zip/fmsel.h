// Sample implementation for a minimal Dark Engine FM Selector

/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details.
 */

#pragma once

#ifndef _FMSEL_H_
#define _FMSEL_H_

#if defined(WIN32) || defined(__CYGWIN__)

#ifdef __GNUC__
#define FMSELAPI __attribute__((dllexport))
#else // !__GNUC__
#define FMSELAPI __declspec(dllexport)
#endif // __GNUC__

#else // !(defined(WIN32) || defined(__CYGWIN__))

#if __GNUC__ >= 4
#define FMSELAPI __attribute__ ((visibility("default")))
#else // !(__GNUC__ >= 4)
#define FMSELAPI
#endif // __GNUC__ >= 4

#endif // defined(WIN32) || defined(__CYGWIN__)

#pragma pack(4)

typedef struct sFMSelectorData
{
	// sizeof(sFMSelectorData)
	int nStructSize;

	// game version string as returned by AppName() (ie. in the form "Thief 2 Final 1.19")
	const char *sGameVersion;

	// supplied initial FM root path (the FM Selector may change this)
	char *sRootPath;
	int nMaxRootLen;

	// buffer to copy the selected FM name
	char *sName;
	int nMaxNameLen;

	// set to non-zero when selector is invoked after game exit (if requested during game start)
	int bExitedGame;
	// FM selector should set this to non-zero if it wants to be invoked after game exits (only done for FMs)
	int bRunAfterGame;

	// optional list of paths to exclude from mod_path/uber_mod_path in + separated format and like the config
	// vars, or if "*" all mod paths are excluded (leave buffer empty for no excludes)
	// the specified exclude paths work as if they had a "*\" wildcard prefix
	char *sModExcludePaths;
	int nMaxModExcludeLen;
} sFMSelectorData;

#pragma pack()


typedef enum eFMSelReturn
{
	kSelFMRet_OK		= 0,	// run selected FM 'data->sName' (0-len string to run without an FM)
	kSelFMRet_Cancel	= -1,	// cancel FM selection and start game as-is (no FM or if defined in cam_mod.ini use that)
	kSelFMRet_ExitGame	= 1		// abort and quit game
} eFMSelReturn;


extern "C" int FMSELAPI SelectFM(sFMSelectorData *data);

#endif // _FMSEL_H_
