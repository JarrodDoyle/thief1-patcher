/* GlobalServer is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * GlobalServer is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with GlobalServer.
 */

#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>

#ifndef WIN32

#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <pthread.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <poll.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/resource.h>

#define closesocket close
#define neterrno errno

#define INVALID_SOCKET -1
#define SOCKET_ERROR -1
typedef int SOCKET;

#ifndef GUID_DEFINED
#define GUID_DEFINED
#pragma pack(1)
typedef struct _GUID
{
    uint32_t Data1;
    unsigned short Data2;
    unsigned short Data3;
    unsigned char Data4[8];
} GUID;
#pragma pack()
#endif


#define Error(fmt, ...) \
	fprintf(stderr, "Error: " fmt "\n", ## __VA_ARGS__)

#ifdef _DEBUG
#define Debug(fmt, ...) \
	fprintf(stdout, "Debug: " fmt "\n", ## __VA_ARGS__)
#else
#define Debug(fmt, ...) \
	do {} while (0)
#endif

#else // WIN32

#include <io.h>
#include <process.h>
#include <winsock2.h>

#define neterrno WSAGetLastError()
#define pollfd WSAPOLLFD
#define poll WSAPoll
#define EWOULDBLOCK WSAEWOULDBLOCK
#define ECONNREFUSED WSAECONNREFUSED
typedef unsigned __int32 uint32_t;
typedef int socklen_t;


#define Error(fmt, ...) \
	fprintf(stderr, "Error: " fmt "\n", __VA_ARGS__)

#ifdef _DEBUG
#define Debug(fmt, ...) \
	fprintf(stdout, "Debug: " fmt "\n", __VA_ARGS__)
#else
#define Debug(fmt, ...) \
	do {} while (0)
#endif

#endif // WIN32



#define IP_MATCH(__sin_addr1, __sin_addr2) \
	((__sin_addr1).sin_port == (__sin_addr2).sin_port && (__sin_addr1).sin_addr.s_addr == (__sin_addr2).sin_addr.s_addr)

#define IP_FMT_STR "%s:%d"
#define IP_FMT_PARAMS(__sin_addr) \
	inet_ntoa((__sin_addr).sin_addr), (unsigned int)(unsigned short)(__sin_addr).sin_port


#define MAX_PENDING_CONNECTIONS	5
#define MAX_SERVERS				128
// number of descriptors that can be passed to poll() on *nix is limited to RLIMIT_NOFILE, so actual used value may end up lower
#define MAX_CONNECTIONS			1023

// max seconds for a connection to not receive any network messages before forcibly closing the connection
#define MAX_IDLE_TIME			60

// minimum number of seconds between idle timeout checks
#define GC_PERIOD				60


int g_port = 5199;
int g_daemon = 0;
int g_maxconnections = MAX_CONNECTIONS;


// --------------------------------------------------------------------------

/*
   Protocol quick overview:

   A game connects to the global server, the global server does not send any message.
   The game is expected to send either a ListRequest, thereby identifying itself as a game client,
   or it sends a Heartbeat, identifying itself as a game host.

   For connected clients the global server will send server add/update/remove messages.
   Connected hosts are expected to send periodical Heartbeat or HeartbeatMinimal messages.

   If any connection type doesn't send a message within MAX_IDLE_TIME seconds, the global
   server will disconnect (within a minute after that).
*/


// GlobalServer protocol version
#define PROTOCOL_VER			1100

// System message IDs
#define MsgID_SysBase			100
// Game message IDs
#define MsgID_GameBase			200

// GlobalServer -> Client
#define MsgID_RemoveServer		(MsgID_SysBase + 2)
#define MsgID_ServerInfo		(MsgID_GameBase + 1)

// Client -> GlobalServer
#define MsgID_ListRequest		(MsgID_SysBase + 1)
#define MsgID_ClientExit		(MsgID_SysBase + 3)
#define MsgID_ServerClosed		(MsgID_SysBase + 50)
#define MsgID_Heartbeat			(MsgID_GameBase + 50)	// heartbeats come in around every 10 seconds
#define MsgID_HeartbeatMinimal	(MsgID_GameBase + 51)	//


// Game state flags (int sServerInfo)
#define GAME_STATE_OPEN			(1<<0)
#define GAME_STATE_CLOSED		(1<<1)
#define GAME_STATE_PASSWORD		(1<<2)


#pragma pack(1)

struct sMsgBase
{
	unsigned short type;

	static int CopyStringFromN(const char *netData, char *dst, int dstSize)
	{
		memset(dst, 0, dstSize);
		strncpy(dst, netData, dstSize);
		dst[dstSize-1] = 0;
		int len = (int)strlen(dst);
		// make sure net data is valid by making sure it has a null-terminated string that isn't longer than allowed
		return netData[len] ? 0 : len + 1;
	}

	static int CopyStringFromH(const char *src, char *netData)
	{
		strcpy(netData, src);
		return (int)strlen(src) + 1;
	}
};

struct sServerInfo
{
	unsigned short port;
	unsigned char stateFlags;
	unsigned char _reserved[3];
	GUID gameID;
	char serverName[32];
	char mapName[32];

	int operator !=(const sServerInfo &si) const
	{
		return port != si.port || stateFlags != si.stateFlags || strcmp(serverName, si.serverName)
			|| strcmp(mapName, si.mapName) || memcmp(&gameID, &si.gameID, sizeof(GUID));
	}

	int NtoH(const char *netData)
	{
		port = ntohs(*(unsigned short*)(netData));
		stateFlags = (unsigned char)netData[2];
		//skip _reserved
		gameID.Data1 = ntohl(*(uint32_t*)(netData+6));
		gameID.Data2 = ntohs(*(unsigned short*)(netData+10));
		gameID.Data3 = ntohs(*(unsigned short*)(netData+12));
		memcpy(gameID.Data4, netData+14, 8);
		netData += 22;
		int res = sMsgBase::CopyStringFromN(netData, serverName, sizeof(serverName));
		if (res <= 0)
			return 0;
		netData += res;
		res = sMsgBase::CopyStringFromN(netData, mapName, sizeof(mapName));
		return res > 0 && port != 0;
	}

	int HtoN(char *netData)
	{
		*(unsigned short*)netData = htons(port);
		(unsigned char&)netData[2] = stateFlags;
		netData[5] = netData[4] = netData[3] = 0;//_reserved
		*(uint32_t*)(netData+6) = htonl(gameID.Data1);
		*(unsigned short*)(netData+10) = htons(gameID.Data2);
		*(unsigned short*)(netData+12) = htons(gameID.Data3);
		memcpy(netData+14, gameID.Data4, 8);
		int len = 22 + sMsgBase::CopyStringFromH(serverName, netData+22);
		len += sMsgBase::CopyStringFromH(mapName, netData+len);
		return len;
	}
};


// Client messages

struct Msg_ListRequest : sMsgBase
{
	Msg_ListRequest() { type = MsgID_ListRequest; }

	unsigned short protocolVer;

	int NtoH(const char *netData)
	{
		type = ntohs(*(unsigned short*)netData);
		protocolVer = ntohs(*(unsigned short*)(netData+2));
		return 1;
	}
};

struct Msg_ServerClosed : sMsgBase
{
	Msg_ServerClosed() { type = MsgID_ServerClosed; }

	int NtoH(const char *netData) { type = ntohs(*(unsigned short*)netData); return 1; }
};

struct Msg_ClientExit : sMsgBase
{
	enum eReason
	{
		rJoinedGame,
		rAppCrash,
		rQuit
	};

	Msg_ClientExit() { type = MsgID_ClientExit; }

	unsigned char reason;

	int NtoH(const char *netData)
	{
		type = ntohs(*(unsigned short*)netData);
		reason = (unsigned char)netData[2];
		return 1;
	}
};

struct Msg_Heartbeat : sMsgBase
{
	Msg_Heartbeat() { type = MsgID_Heartbeat; }

	unsigned short protocolVer;
	sServerInfo si;

	// min message length is if both strings in si are empty
	static int MinLen() { return 26 + 1 + 1; }

	int NtoH(const char *netData)
	{
		type = ntohs(*(unsigned short*)netData);
		protocolVer = ntohs(*(unsigned short*)(netData+2));
		return protocolVer <= PROTOCOL_VER && si.NtoH(netData+4);
	}
}; // max 88 bytes (depending on string lengths)

struct Msg_HeartbeatMinimal : sMsgBase
{
	Msg_HeartbeatMinimal() { type = MsgID_HeartbeatMinimal; }

	int NtoH(const char *netData)
	{
		type = ntohs(*(unsigned short*)netData);
		return 1;
	}
};

#define SIZEOF_LARGEST_CLIENT_MSG sizeof(Msg_Heartbeat)


// Server/Host messages

struct Msg_RemoveServer : sMsgBase
{
	Msg_RemoveServer() { type = MsgID_RemoveServer; }

	unsigned short port;
	char serverIP[16];

	int HtoN(char *netData)
	{
		*(unsigned short*)netData = htons(type);
		*(unsigned short*)(netData+2) = htons(port);
		int len = CopyStringFromH(serverIP, netData+4);
		return 4 + len;
	}
};

struct Msg_ServerInfo : sMsgBase
{
	Msg_ServerInfo() { type = MsgID_ServerInfo; }

	sServerInfo si;
	char serverIP[16];

	// return non-zero if any values changed
	int CopyInfo(const Msg_Heartbeat &src)
	{
		int ret = si != src.si;

		si = src.si;

		return ret;
	}

	void SetIP(const struct sockaddr_in &addr)
	{
		strcpy(serverIP, inet_ntoa(addr.sin_addr));
	}

	int HtoN(char *netData)
	{
		*(unsigned short*)netData = htons(type);
		int len = 2 + si.HtoN(netData+2);
		len += CopyStringFromH(serverIP, netData+len);
		return len;
	}
}; // max 104 bytes (depending on string lengths)

#pragma pack()


// --------------------------------------------------------------------------

struct sServer
{
	int pfdIndex;

	Msg_ServerInfo info;

	time_t lastPingTime;

	sServer *next;

	sServer()
	{
		pfdIndex = 0;
		next = NULL;
	}
};


struct sConnection
{
	enum eNetState
	{
		nsNewlyConnected,			// nothing receive yet, undetermined if other side is a client or a server
		nsAwaitServerCommand,
		nsAwaitClientCommand,

		nsUnused,
	};

	enum eFlags
	{
		flHasRequestedList = 1<<0,	// this connection has sent a ListRequest message
	};

	int netState;
	int flags;

	// TODO: flood protection, kick off servers or clients that send too many commands or heartbeats within a certain time

	time_t connectionTime;
	// time of last received (valid) message
	time_t lastActiveTime;

	sServer *srv;

	SOCKET sock;
	struct sockaddr_in addr;

	sConnection()
	{
		netState = nsUnused;
		flags = 0;
		srv = NULL;
		sock = INVALID_SOCKET;
	}

	void Init(SOCKET client_sock, const struct sockaddr_in &client_addr)
	{
		netState = nsNewlyConnected;
		flags = 0;
		srv = NULL;
		sock = client_sock;
		addr = client_addr;

		time(&connectionTime);
		lastActiveTime = connectionTime;
	}

	void Free()
	{
		netState = nsUnused;
		flags = 0;
		sock = INVALID_SOCKET;
	}
};


// slot 0 is reserved for the globalserver listening socket, which is not included in g_numConnections
int g_numConnections = 0;

pollfd g_pfds[1+MAX_CONNECTIONS];
sConnection g_conns[1+MAX_CONNECTIONS];

sServer g_srvPool[MAX_SERVERS];
sServer *g_freeSrvList = NULL;

int g_numServers = 0;
sServer *g_serverList = NULL;


// --------------------------------------------------------------------------

int InitNetworking()
{
#ifdef WIN32
	WSADATA wsaData;
	WORD wVersionRequested = MAKEWORD(2, 0);

	if ( WSAStartup(wVersionRequested, &wsaData) )
		return 0;
#endif

	return 1;
}

void ExitNetworking()
{
#ifdef WIN32
	WSACleanup();
#endif
}


// --------------------------------------------------------------------------

int SetSocketNonBlocking(int sock)
{
#ifndef WIN32
	if (fcntl(sock, F_SETFL, O_NONBLOCK) < 0)
	{
		Error("failed to enable non-blocking I/O (errno %d)", neterrno);
		return 0;
	}
#else // WIN32
	{
	DWORD dw = TRUE;
	if ( ioctlsocket(sock, FIONBIO, &dw) )
	{
		Error("failed to enable non-blocking I/O (errno %d)", neterrno);
		return 0;
	}
	}
#endif // WIN32

	return 1;
}


// --------------------------------------------------------------------------

void RemoveServer(sServer *srv)
{
	// remove server from g_serverList
	if (srv == g_serverList)
		g_serverList = srv->next;
	else
	{
		sServer *itr = g_serverList;
		for (; itr && itr->next!=srv; itr=itr->next);
		if (!itr)
			return;
		itr->next = srv->next;
	}

	// add to free-list
	srv->next = g_freeSrvList;
	g_freeSrvList = srv;

	g_numServers--;
}


// --------------------------------------------------------------------------

void RemoveConnection(const int i)
{
	g_pfds[i].fd = INVALID_SOCKET;
	g_pfds[i].events = 0;
	g_pfds[i].revents = 0;

	sConnection *con = &g_conns[i];

	if (con->srv)
	{
		sServer *srv = con->srv;
		con->srv = NULL;

		RemoveServer(srv);
	}

	con->Free();

	g_numConnections--;
}


// --------------------------------------------------------------------------

void NotifyServerRemoval(sServer *srv);

void CloseConnection(const int i)
{
	sConnection *con = &g_conns[i];

	Debug("closed connection " IP_FMT_STR, IP_FMT_PARAMS(con->addr));

	if (con->srv)
	{
		sServer *srv = con->srv;
		con->srv = NULL;

		NotifyServerRemoval(srv);
	}

	shutdown(con->sock, 2);
	closesocket(con->sock);

	RemoveConnection(i);
}


// --------------------------------------------------------------------------

void AddConnection(const SOCKET client_sock, const struct sockaddr_in &client_addr)
{
	if (g_numConnections >= g_maxconnections)
	{
		Error("max connections reached");
		shutdown(client_sock, 2);
		closesocket(client_sock);
		return;
	}

	// make sure there's no existing connection from the same client_addr
	for (int i=1; i<=g_maxconnections; i++)
		if (g_conns[i].netState != sConnection::nsUnused && IP_MATCH(g_conns[i].addr, client_addr) && g_conns[i].addr.sin_port == client_addr.sin_port)
		{
			Debug("multiple connections from same address and port, closing previous. " IP_FMT_STR, IP_FMT_PARAMS(client_addr));
			CloseConnection(i);
			break;
		}

	// could maintain a free-list of connections, but the max connections and server load for this game is likely to be tiny

	// TODO: limit number of connections from a single IP to reduce potential of malicious attacks (a few connections would be ok, for exmaple
	//       if a household that typically has a single WAN IP for all computers was running multiple servers or playing on multiple computers)

	// find free entry
	int i;
	for (i=1; i<=g_maxconnections; i++)
		if (g_conns[i].netState == sConnection::nsUnused)
			break;

	sConnection *con = &g_conns[i];

	con->Init(client_sock, client_addr);

	g_pfds[i].events = POLLIN;
	g_pfds[i].revents = 0;
	g_pfds[i].fd = con->sock;

	g_numConnections++;

	Debug("added connection " IP_FMT_STR, IP_FMT_PARAMS(client_addr));
}


// --------------------------------------------------------------------------

void NotifyServerRemoval(sServer *srv)
{
	// send RemoveServer message to all clients that have already requested the server list

	Msg_RemoveServer msg;
	msg.port = srv->info.si.port;
	memcpy(msg.serverIP, srv->info.serverIP, sizeof(msg.serverIP));

	RemoveServer(srv);

	char buf2[sizeof(msg)];
	int len = msg.HtoN(buf2);

	for (int i=1; i<g_maxconnections; i++)
	{
		sConnection *con = &g_conns[i];

		if (con->netState != sConnection::nsAwaitClientCommand || !(con->flags & sConnection::flHasRequestedList))
			continue;

		int res2 = send(con->sock, buf2, len, 0);
		if (res2 != len)
		{
			Debug("failed to send RemoveServer to " IP_FMT_STR " (errno %d)", IP_FMT_PARAMS(con->addr), neterrno);
		}
	}
}


// --------------------------------------------------------------------------

void NotifyServerAdditionOrUpdate(sServer *srv)
{
	// send ServerInfo message to all clients that have already requested the server list

	Msg_ServerInfo msg;

	char buf2[sizeof(msg)];
	int len = srv->info.HtoN(buf2);

	for (int i=1; i<g_maxconnections; i++)
	{
		sConnection *con = &g_conns[i];

		if (con->netState != sConnection::nsAwaitClientCommand || !(con->flags & sConnection::flHasRequestedList))
			continue;

		int res2 = send(con->sock, buf2, len, 0);
		if (res2 != len)
		{
			Debug("failed to send ServerInfo to " IP_FMT_STR " (errno %d)", IP_FMT_PARAMS(con->addr), neterrno);
		}
	}
}


// --------------------------------------------------------------------------

void ReceiveFromConnection(const int pfdIndex, const time_t curTime)
{
	g_pfds[pfdIndex].revents = 0;

	sConnection *con = &g_conns[pfdIndex];

	if (con->netState > sConnection::nsAwaitClientCommand)
	{
		Debug("connection dropped, connection not expecting to receive any messages");
		CloseConnection(pfdIndex);
		return;
	}

	// only care about receive as many bytes as a command message needs, if someone tries to send more the rest is just thrown away
	// (or better yet the connection is closed, assuming something malicious is in progress)
	const int BUFSIZE = 256;
	union
	{
	char buf[BUFSIZE];
	unsigned short buf16[BUFSIZE/2];
	};

	// TODO: do I need non-blocking so I can read as much data as is available without accidentally ending up in a blocked receive that waits for more data?
	int res = recv(con->sock, buf, sizeof(buf), 0);

	if (res < (int)sizeof(sMsgBase))
	{
		Debug("connection dropped, no valid sMsgBase data");
		CloseConnection(pfdIndex);
		return;
	}

	unsigned int msgType = (unsigned int) ntohs(*buf16);

	#define INIT_INMSG_VARLEN(__msg, __minlen) \
		if (res < (int)__minlen) \
		{ \
			Debug("connection dropped, received message data for " #__msg " message too short (%d bytes, expected %d bytes)", res, sizeof(Msg_##__msg)); \
			CloseConnection(pfdIndex); \
			return; \
		} \
		Msg_##__msg msg; \
		if ( !msg.NtoH(buf) ) \
		{ \
			Debug("connection dropped, failed to convert network data to message data for " #__msg " message, bad message format or unsupported protocol version"); \
			CloseConnection(pfdIndex); \
			return; \
		}

	#define INIT_INMSG(__msg) INIT_INMSG_VARLEN(__msg, sizeof(Msg_##__msg))

	switch (msgType)
	{
	// client messages

	case MsgID_ListRequest:
		if (con->netState == sConnection::nsNewlyConnected)
		{
			// first message received from a connection, the first message being ListRequest means it identifies itself as a client
			con->netState = sConnection::nsAwaitClientCommand;
		}
		else if (con->srv || con->netState != sConnection::nsAwaitClientCommand)
		{
			Debug("connection dropped, received ListRequest message on a non-client connection");
			CloseConnection(pfdIndex);
			return;
		}
		{
		INIT_INMSG(ListRequest);
		con->flags |= sConnection::flHasRequestedList;

		Debug("MSG_ListRequest: from " IP_FMT_STR, IP_FMT_PARAMS(con->addr));

		if (msg.protocolVer > PROTOCOL_VER)
		{
			Debug("connection dropped, ListRequest message is using a newer protocol version than supported by this global server");
			CloseConnection(pfdIndex);
			return;
		}

		// TODO: have some minimum wait time or limit number of requests for a certain time window to avoid server send-load "attacks"

		char buf2[sizeof(Msg_ServerInfo)];

		for (sServer *itr=g_serverList; itr; itr=itr->next)
		{
			int len = itr->info.HtoN(buf2);

			int res2 = send(con->sock, buf2, len, 0);
			if (res2 != len)
			{
				Debug("failed to send ServerInfo to " IP_FMT_STR " (errno %d)", IP_FMT_PARAMS(con->addr), neterrno);
			}
		}
		}
		break;

	case MsgID_ClientExit:
		{
		INIT_INMSG(ClientExit);
		Debug("MSG_ClientExit: from " IP_FMT_STR, IP_FMT_PARAMS(con->addr));
		CloseConnection(pfdIndex);
		return;
		}
		break;

	// server/host messages

	case MsgID_ServerClosed:
		if (!con->srv || con->netState != sConnection::nsAwaitServerCommand)
		{
			// not a server
			Debug("connection dropped, received ServerClosed message on a non-server connection");
			CloseConnection(pfdIndex);
			return;
		}
		{
		INIT_INMSG(ServerClosed);
		sServer *srv = con->srv;
		con->srv = NULL;
		CloseConnection(pfdIndex);

		Debug("MSG_ServerClosed: from %s:%d", srv->info.serverIP, (unsigned int)srv->info.si.port);

		NotifyServerRemoval(srv);
		}
		return;

	case MsgID_Heartbeat:
		{
		int notify_clients = 0;
		if (con->netState == sConnection::nsNewlyConnected)
		{
			// first message received from a connection, the first message being Heartbeat means it identifies itself as a server(/host)

			if (!g_freeSrvList)
			{
				// max server capacity reached
				Debug("connection refused, no more free server slots");
				CloseConnection(pfdIndex);
				return;
			}

			// assign sServer entry to connection

			con->srv = g_freeSrvList;
			g_freeSrvList = g_freeSrvList->next;

			con->srv->pfdIndex = pfdIndex;

			con->srv->next = g_serverList;
			g_serverList = con->srv;

			con->netState = sConnection::nsAwaitServerCommand;

			g_numServers++;

			notify_clients = 1;

			Debug("added new server entry for " IP_FMT_STR, IP_FMT_PARAMS(con->addr));
		}
		else if (!con->srv || con->netState != sConnection::nsAwaitServerCommand)
		{
			Debug("connection dropped, received Heartbeat message on a non-server connection");
			CloseConnection(pfdIndex);
			return;
		}
		INIT_INMSG_VARLEN(Heartbeat, Msg_Heartbeat::MinLen());
		sServer *srv = con->srv;
		if ( srv->info.CopyInfo(msg) )
			notify_clients = 1;
		srv->lastPingTime = curTime;
		// fill in info.serverIP
		srv->info.SetIP(con->addr);

		Debug("MSG_Heartbeat: from %s:%d, state:%X, SrvName: '%s', Map:'%s'", srv->info.serverIP, (unsigned int)srv->info.si.port, (unsigned int)srv->info.si.stateFlags, srv->info.si.serverName, srv->info.si.mapName);

		if (notify_clients)
			NotifyServerAdditionOrUpdate(con->srv);
		}
		break;

	case MsgID_HeartbeatMinimal:
		if (!con->srv || con->netState != sConnection::nsAwaitServerCommand)
		{
			// not a server
			Debug("connection dropped, received HeartbeatMinimal message on a non-server connection");
			CloseConnection(pfdIndex);
			return;
		}
		{
		INIT_INMSG(HeartbeatMinimal);
		sServer *srv = con->srv;
		srv->lastPingTime = curTime;

		Debug("MSG_HeartbeatMinimal: from %s:%d", srv->info.serverIP, (unsigned int)srv->info.si.port);
		}
		break;

	default:
		Debug("received unknown message %d from " IP_FMT_STR, msgType, IP_FMT_PARAMS(con->addr));
		CloseConnection(pfdIndex);
		return;
	}

	con->lastActiveTime = curTime;
}


// --------------------------------------------------------------------------

SOCKET g_sock = INVALID_SOCKET;

int RunServer()
{
	memset(g_pfds, 0, sizeof(g_pfds));
	for (int i=0; i<=MAX_CONNECTIONS; i++)
		g_pfds[i].fd = INVALID_SOCKET;

	for (int i=0; i<MAX_SERVERS-1; i++)
		g_srvPool[i].next = &g_srvPool[i+1];
	g_freeSrvList = &g_srvPool[0];

#ifndef WIN32
	// determine max sockets poll() can listen to, limited to max open file handles on (some?) *nix
	{
	struct rlimit rl;
	if (!getrlimit(RLIMIT_NOFILE, &rl) && (int)rl.rlim_cur <= g_maxconnections)
	{
		if (rl.rlim_max > rl.rlim_cur)
		{
			// try to increase the soft limit
			struct rlimit rl2 = rl;
			rl2.rlim_cur = ((int)rl2.rlim_max > g_maxconnections ? g_maxconnections+1 : rl2.rlim_max);
			if ( setrlimit(RLIMIT_NOFILE, &rl2) )
				Debug("failed to increase RLIMIT_NOFILE soft limit to %d", (int)rl2.rlim_cur);
			else
			{
				Debug("increased RLIMIT_NOFILE soft limit from %d to %d", (int)rl.rlim_cur, (int)rl2.rlim_cur);
				rl.rlim_cur = rl2.rlim_cur;
			}
		}

		if ((int)rl.rlim_cur <= g_maxconnections)
		{
			if ((int)rl.rlim_cur < 8)
			{
				Error("can't run server, RLIMIT_NOFILE too low (%d)", (int)rl.rlim_cur);
				return 0;
			}

			g_maxconnections = (int)rl.rlim_cur - 1;

			fprintf(stdout, "max connections adjusted down to %d due to RLIMIT_NOFILE (soft:%d hard:%d)\n\n", g_maxconnections, (int)rl.rlim_cur, (int)rl.rlim_max);
		}
	}
	}
#endif

	SOCKET sock;

	if ((sock = socket(AF_INET, SOCK_STREAM, IPPROTO_IP)) < 0)
	{
		Error("failed to create socket (errno %d)", neterrno);
		return 0;
	}

	// allow the network service to be restarted when there are connections in the ESTABLISHED or TIME-WAIT state
	int reuseaddr = 1;
	if (setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuseaddr, sizeof(reuseaddr)) == SOCKET_ERROR)
	{
		Error("failed to set SO_REUSEADDR on socket (errno %d)", neterrno);
		shutdown(sock, 2);
		closesocket(sock);
		return 0;
	}

	struct sockaddr_in serv_addr = {0};
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons((unsigned short)g_port);

	if (bind(sock, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) == SOCKET_ERROR)
	{
		Error("failed to bind socket (errno %d)", neterrno);
		shutdown(sock, 2);
		closesocket(sock);
		return 0;
	}

	if (listen(sock, MAX_PENDING_CONNECTIONS) == SOCKET_ERROR)
	{
		Error("failed to listen on socket (errno %d)", neterrno);
		shutdown(sock, 2);
		closesocket(sock);
		return 0;
	}

	g_pfds[0].fd = sock;
	g_pfds[0].events = POLLRDNORM;
	g_pfds[0].revents = 0;

	time_t curTime;
	time(&curTime);

	// check for idle timed out connections from time to time
	time_t nextGarbageCollectTime = curTime + GC_PERIOD;

	// ---- server loop ----

	for (;;)
	{
		int res = poll(g_pfds, g_maxconnections+1, 60 * 1000);

		time_t curTime;
		time(&curTime);

		if (res <= 0)
		{
			if (res == SOCKET_ERROR)
			{
				Error("poll() failed (errno %d)", neterrno);
				break;
			}

			// poll() timed out
		}
		else
		{
			if (g_pfds[0].revents & POLLRDNORM)
			{
				// new connection on server socket

				struct sockaddr_in client_addr = {0};
				SOCKET client_sock;
				socklen_t addrlen = sizeof(client_addr);

				if ((client_sock = accept(sock, (struct sockaddr*)&client_addr, &addrlen)) == INVALID_SOCKET)
				{
					Error("failed to a accept connection (errno %d)", neterrno);
					continue;
				}

				AddConnection(client_sock, client_addr);
			}

			for (int i=1; i<=g_maxconnections; i++)
			{
				if (g_pfds[i].revents)
				{
					if (g_pfds[i].revents & POLLIN)
						ReceiveFromConnection(i, curTime);
					else if (g_pfds[i].revents & POLLHUP)
						CloseConnection(i);

					g_pfds[i].revents = 0;
				}
			}
		}

		// periodically check for idle timeouts
		if (curTime >= nextGarbageCollectTime)
		{
			nextGarbageCollectTime = curTime + GC_PERIOD;

			for (int i=1; i<=g_maxconnections; i++)
			{
				if (g_conns[i].netState == sConnection::nsUnused)
					continue;

				if ((curTime - g_conns[i].lastActiveTime) > MAX_IDLE_TIME)
				{
					Error("connection timed out");
					CloseConnection(i);
				}
			}
		}
	}

	g_pfds[0].fd = INVALID_SOCKET;

	shutdown(sock, 2);
	closesocket(sock);

	return 1;
}


// --------------------------------------------------------------------------

void SigHandler(int sig)
{
	if (g_sock != INVALID_SOCKET)
	{
		shutdown(g_sock, 2);
		closesocket(g_sock);
	}
	for (int i=1; i<=g_maxconnections; i++)
		if (g_pfds[i].fd != INVALID_SOCKET)
		{
			shutdown(g_pfds[i].fd, 2);
			closesocket(g_pfds[i].fd);
		}
	exit(1);
}


// --------------------------------------------------------------------------

#ifdef WIN32

int CreateConsole()
{
	if ( !AllocConsole() )
		return 0;

	SetConsoleTitle("GlobalServer");

	// disable X-button
	HWND hWnd = GetConsoleWindow();
	HMENU hMenu = GetSystemMenu(hWnd, FALSE);
	DeleteMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);

	// enable mousewheel scroll and quick edit
	DWORD dwConMode;
	if ( GetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), &dwConMode) )
		SetConsoleMode(GetStdHandle(STD_INPUT_HANDLE), (dwConMode & ~ENABLE_MOUSE_INPUT) | ENABLE_EXTENDED_FLAGS | ENABLE_QUICK_EDIT_MODE);

	// redirect stdout/tderr to the console window
	freopen("CONOUT$", "w", stdout);
	freopen("CONOUT$", "w", stderr);

	return 1;
}

#endif


// --------------------------------------------------------------------------

#ifndef WIN32
int main(int argc, char* argv[])
#else
int CALLBACK WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowcmd)
#endif
{
#ifdef WIN32
	char** argv = __argv;
	int argc = __argc;

	if ( !strstr(lpCmdLine, "--daemon") )
		CreateConsole();
#endif

	// command line: globalserver [--daemon] [--max-connections=<n>] [<port_num>]

	// command-line arguments
	if (argc > 1)
	{
		for (int i=1; i<argc; i++)
		{
			if ( !strncmp(argv[i], "--", 2) )
			{
				if ( !strcmp(argv[i]+2, "daemon") )
					g_daemon = 1;
				else if ( !strncmp(argv[i]+2, "max-connections=", 16) )
				{
					g_maxconnections = atoi(argv[i]+18);

					if (g_maxconnections < 8)
					{
						fprintf(stderr, "Warning: max-connections must be at least 8\n");
						g_maxconnections = 8;
					}
					else if (g_maxconnections > MAX_CONNECTIONS)
					{
						fprintf(stderr, "Warning: max-connections can be at most %d\n", MAX_CONNECTIONS);
						g_maxconnections = MAX_CONNECTIONS;
					}
				}
				else
				{
					Error("invalid argument: %s", argv[i]);
					fprintf(stdout, "use: globalserver [--daemon] [--max-connections=<n>] [<port_num>]\n");
					return 2;
				}
			}
			else
			{
				g_port = atoi(argv[i]);
				if (g_port <= 0 || g_port >= 65536)
				{
					Error("illegal port number %d", g_port);
					return 2;
				}
			}
		}
	}

#ifndef WIN32
	if (g_daemon && daemon(0, 0) == -1)
	{
		Error("failed to switch to daemon mode (errno %d)", errno);
		return 1;
	}
#endif

	if ( !InitNetworking() )
		return 1;

	if (!g_daemon)
	{
		// allow Ctrl-C abort
		signal(SIGINT, SigHandler);
		fprintf(stdout, "server listening on port %d\n\n", g_port);
		fprintf(stdout, "press Ctrl+C to terminate server...\n");
	}

	if ( !RunServer() )
	{
		ExitNetworking();
		return 1;
	}

	ExitNetworking();

	return 0;
}
